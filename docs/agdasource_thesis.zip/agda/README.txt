    T R U N C A T I O N   L E V E L S
                 I N
H O M O T O P Y   T Y P E   T H E O R Y

======= ELECTRONIC APPENDIX =======

             PhD Thesis

           NICOLAI KRAUS

           February 2015
 

This appendix contains Agda formalisations 
of some results presented in the thesis.

Agda is a proof assistant and dependently 
typed programming language that is (besides
Coq) often used to formalise and verify 
internal results of Homotopy Type Theory
(HoTT). Agda is not a precise implementation
of the theory that I work in in the thesis,
but a sufficiently close approximation; 
differences (and potentially debatable 
features) are discussed in the thesis in
Chapter 1.4.

For more background on Agda, I refer to

  Ulf Norell, Towards a practical 
  programming language based on dependent 
  type theory.

CONTENTS: 
  (1) The folder "agda". The root file 
      which imports everything else (and
      contains documentation that guide 
      through the code) is "INDEX.agda".
      To typecheck, Agda release 2.4.2 is
      required (both newer and older ver-
      sions might not work). Apart from 
      this, the contents of the folder 
      "agda" are self-contained; no further 
      libraries are needed. We do use 
      library files of the HoTT GitHub 
      library, available at
        https://github.com/HoTT/HoTT-Agda
      but these files are contained in the 
      subdirectory "lib" of this appendix.

      To type-check, change to the directory
      "agda" and run
          agda INDEX.agda
        
  (2) The folder "agda-html" contains the 
      whole formalisation as html, i.e. in 
      browser-viewable format. This way,
      the formalisation can be read without
      the need for an Agda installation;
      all that is required is an ordinary
      internet browser. I suggest to the 
      interested reader who has no experience
      with Agda to look at this version. It 
      was generated using Agda's html 
      feature, i.e. by running
          agda --html INDEX.agda --html-dir=../agda-html

      Note that this command type-checks
      everything and the html is only produced
      if there are no problems; hence, the 
      html itself can be seen as evidence 
      that the formalisation is correct.
      
  (3) This README file.



